# Stand Arena - Android prototype

An original, JoJo-inspired 2D arena fighter prototype for Android. It uses original placeholder fighters and does not include copyrighted JoJo character art, music, logos, or dialogue.

## Included
- Landscape Android app
- Touch movement, hit, and special attack buttons
- Health bars, simple CPU opponent, win/lose and restart
- Native Kotlin Canvas rendering; no external assets required

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder as a project.
3. Let Gradle sync.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

This is a starter prototype, not a finished commercial fighting game. The source project is provided; an APK has not been compiled or device-tested in this environment.
