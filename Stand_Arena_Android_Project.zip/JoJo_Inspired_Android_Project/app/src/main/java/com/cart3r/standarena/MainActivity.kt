package com.cart3r.standarena

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.MotionEvent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )
        setContentView(FightView(this))
    }
}

private class Fighter(var x: Float, var color: Int, var hp: Float = 100f, var facing: Float = 1f,
                      var attackTimer: Int = 0, var stun: Int = 0)

private class FightView(context: android.content.Context) : View(context) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private lateinit var player: Fighter
    private lateinit var enemy: Fighter
    private var last = System.currentTimeMillis()
    private var elapsed = 0
    private var message = "FIGHT!"
    private var messageTimer = 90
    private var moveLeft = false
    private var moveRight = false
    private var attacking = false
    private var special = false
    private var gameOver = false

    init {
        player = Fighter(170f, Color.rgb(30, 190, 210))
        enemy = Fighter(650f, Color.rgb(225, 65, 105), facing = -1f)
        isFocusable = true
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int = Color.WHITE) {
        p.color = color; p.textSize = size; p.typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        c.drawText(s, x, y, p)
    }
    private fun bar(c: Canvas, x: Float, y: Float, w: Float, hp: Float, color: Int) {
        p.color = Color.rgb(50, 35, 48); c.drawRoundRect(x, y, x+w, y+18, 8f, 8f, p)
        p.color = color; c.drawRoundRect(x, y, x+w*(hp/100f).coerceIn(0f,1f), y+18, 8f, 8f, p)
    }
    private fun button(c: Canvas, r: RectF, label: String, active: Boolean = false) {
        p.color = if (active) Color.rgb(255, 55, 85) else Color.argb(210, 25, 23, 39)
        c.drawRoundRect(r, 18f, 18f, p)
        p.color = Color.rgb(255, 110, 130); p.style = Paint.Style.STROKE; p.strokeWidth = 3f
        c.drawRoundRect(r, 18f, 18f, p); p.style = Paint.Style.FILL
        text(c, label, r.centerX()-p.measureText(label)/2, r.centerY()+12, 24f)
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        // arena backdrop
        p.shader = android.graphics.LinearGradient(0f,0f,0f,h, Color.rgb(17,15,39), Color.rgb(75,25,62), android.graphics.Shader.TileMode.CLAMP)
        c.drawRect(0f,0f,w,h,p); p.shader = null
        p.color = Color.rgb(37,27,52); c.drawRect(0f,h*.72f,w,h,p)
        p.color = Color.rgb(105,55,87); c.drawRect(0f,h*.72f,w,h*.735f,p)
        for (i in 0..8) {
            p.color = Color.argb(35,255,255,255)
            c.drawLine(i*w/8,h*.1f,i*w/8,h*.72f,p)
        }

        text(c, "STAND ARENA", w*.39f, 42f, 25f, Color.rgb(255,210,220))
        text(c, "PULSE KNIGHT", 28f, 38f, 18f)
        text(c, "RIFT BEAST", w-150f, 38f, 18f)
        bar(c, 28f, 50f, w*.34f, player.hp, Color.rgb(30,220,205))
        bar(c, w*.66f, 50f, w*.31f, enemy.hp, Color.rgb(255,65,105))
        text(c, "ROUND 1", w*.46f, 91f, 16f, Color.rgb(255,220,120))

        drawFighter(c, player, h*.72f)
        drawFighter(c, enemy, h*.72f)

        val bw = min(86f, w*.12f); val by = h-76f
        button(c, RectF(20f,by-46,20f+bw,by+28), "◀", moveLeft)
        button(c, RectF(28f+bw,by-46,28f+2*bw,by+28), "▶", moveRight)
        button(c, RectF(w-3*bw-30,by-46,w-2*bw-38,by+28), "HIT", attacking)
        button(c, RectF(w-2*bw-22,by-46,w-bw-30,by+28), "SKILL", special)
        button(c, RectF(w-bw-18,by-46,w-18,by+28), "GUARD")
        if (messageTimer > 0) {
            text(c, message, w*.5f-p.measureText(message)/2, h*.28f, 38f, Color.rgb(255,220,110))
        }
        if (gameOver) {
            p.color = 0x99000000.toInt(); c.drawRect(0f,0f,w,h,p)
            val result = if (player.hp > 0) "YOU WIN!" else "YOU LOSE"
            text(c, result, w*.5f-p.measureText(result)/2, h*.48f, 48f, Color.WHITE)
            text(c, "Tap anywhere to restart", w*.5f-115f, h*.58f, 20f, Color.WHITE)
        }
        updateGame()
        postInvalidateDelayed(16)
    }

    private fun drawFighter(c: Canvas, f: Fighter, floor: Float) {
        val bob = if (f.attackTimer > 0) -12f else 0f
        // stylized fighter silhouette + summoned spirit behind
        p.color = Color.argb(85, f.color shr 16 and 255, f.color shr 8 and 255, f.color and 255)
        c.drawOval(f.x-45, floor-155+bob, f.x+45, floor-35+bob, p)
        p.color = f.color
        c.drawRoundRect(f.x-24, floor-105+bob, f.x+24, floor-25+bob, 13f,13f,p)
        c.drawCircle(f.x, floor-132+bob, 23f, p)
        p.color = Color.rgb(245,218,190)
        c.drawCircle(f.x, floor-134+bob, 16f,p)
        p.color = Color.rgb(35,25,45)
        c.drawCircle(f.x-6, floor-137+bob, 2.5f,p); c.drawCircle(f.x+6, floor-137+bob, 2.5f,p)
        p.color = Color.WHITE
        c.drawRoundRect(f.x-38, floor-88+bob, f.x+38, floor-78+bob, 5f,5f,p)
        if (f.attackTimer > 0) {
            p.color = Color.argb(160,255,225,120)
            c.drawCircle(f.x+f.facing*48, floor-112+bob, 20f,p)
        }
    }

    private fun updateGame() {
        val now = System.currentTimeMillis()
        if (now-last < 15) return
        last = now
        if (messageTimer > 0) messageTimer--
        if (gameOver) return
        val speed = width * .0045f
        if (moveLeft) player.x -= speed
        if (moveRight) player.x += speed
        player.x = player.x.coerceIn(45f, width-45f)
        player.facing = if (enemy.x >= player.x) 1f else -1f
        enemy.facing = -player.facing
        if (player.attackTimer > 0) player.attackTimer--
        if (enemy.attackTimer > 0) enemy.attackTimer--
        if (player.stun > 0) player.stun--
        if (enemy.stun > 0) enemy.stun--

        elapsed++
        if (elapsed % 75 == 0 && enemy.stun == 0) {
            enemy.attackTimer = 12
            if (kotlin.math.abs(enemy.x-player.x) < 125f) {
                player.hp = max(0f, player.hp - 5f)
                message = "RIFT STRIKE!"
                messageTimer = 24
            } else {
                enemy.x += enemy.facing*24
            }
        }
        if (attacking && player.attackTimer == 0) {
            player.attackTimer = 18
            if (kotlin.math.abs(enemy.x-player.x) < 145f) {
                enemy.hp = max(0f, enemy.hp-8f); enemy.stun=15
                message = "COMBO HIT!"
                messageTimer = 30
            }
        }
        if (special && player.attackTimer == 0) {
            player.attackTimer = 30
            if (kotlin.math.abs(enemy.x-player.x) < 210f) {
                enemy.hp = max(0f, enemy.hp-18f); enemy.stun=28
                message = "STAND BURST!"
                messageTimer = 40
            } else {
                message = "TOO FAR!"
                messageTimer = 25
            }
        }
        if (player.hp <= 0f || enemy.hp <= 0f) gameOver = true
        attacking = false; special = false
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val w = width.toFloat(); val h = height.toFloat()
        val bw = min(86f, w*.12f); val by = h-76f
        val x=e.x; val y=e.y
        if (gameOver && e.action == MotionEvent.ACTION_DOWN) {
            player.hp=100f; enemy.hp=100f; player.x=w*.25f; enemy.x=w*.75f
            gameOver=false; elapsed=0; message="FIGHT!"; messageTimer=60
            return true
        }
        when(e.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                moveLeft = x in 20f..(20f+bw) && y in (by-46)..(by+28)
                moveRight = x in (28f+bw)..(28f+2*bw) && y in (by-46)..(by+28)
                attacking = x in (w-3*bw-30)..(w-2*bw-38) && y in (by-46)..(by+28)
                special = x in (w-2*bw-22)..(w-bw-30) && y in (by-46)..(by+28)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                moveLeft=false; moveRight=false; attacking=false; special=false
            }
        }
        return true
    }
}
